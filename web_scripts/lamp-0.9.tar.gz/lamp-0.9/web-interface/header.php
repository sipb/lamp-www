<?
require_once("lamp.php");
db_connect();
global $query;
?>

<HTML>
<HEAD>
<TITLE>lamp: Library Access to Music Project</TITLE>
<meta http-equiv="refresh" content="60">
<LINK REL=StyleSheet HREF="<? echo (($style=="")?"config/snarked_style.css":"$style");?>" TYPE="text/css" MEDIA=screen>
</HEAD>
<BODY>
<center>
<div class="snarkedtable">
<div class="headerline">
<table><tr><td>
<form>
<input type="hidden" name="action" value="basic_search">
<span class="headtext" id="maintitle">
<nobr>Library Access to Music Project</nobr></span><br><span class="byline">launching October 27 with 3,437 CDs</span><br>
<nobr><input type=text name="query" value="<?echo stripslashes($query);?>"><input type="submit" name="submit" value="find music">
 [ <a href="?action=advanced_search_form">advanced search</a> | <a href="?action=browse_albums_form">browse music</a> | <a href="?action=suggestion_form">request music</a> ]</nobr>

</form>
</td><td width="100%"></td><td>
</td></tr>
</table>
</div>
<div class="basictext">
<div class="vspace"></div>
