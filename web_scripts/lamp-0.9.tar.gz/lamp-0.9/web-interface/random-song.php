<?
require_once("lamp.php");
db_connect();

$q = "select track_id, track_filename from tracks ORDER BY RAND() LIMIT 0,1";
$q = db_query($q);

if ($r = db_fetch_array($q)) {
	$song = new Music("song", $r[track_id]);
	$tvname = $song->get_tvname();
	echo $r[track_filename] . "\n" . $r[track_id] . "\n " . $tvname;
	
}

?>