<?

	require_once("lamp.php");

	global $begintime;
	$begintime = getmicrotime();

	db_connect();
	output_header();
	$username = get_username();
	if ($username == "") {
		echo "<div class='headtext'>Welcome to LAMP.<P><P>Please have your certificates ready, and <a href=\"https://lamp.mit.edu/\">select your music.</a></div>";
	output_footer();
		exit;
	}
?>
<table>
<tr>
<td class="left_third">
<? output_controlbox($username);
output_playlist($username); ?>
<br>
<?output_now_playing($username);?>
</td>
<td class="middle_third">
<div class="maincell">

<?
if ($action=="basic_search") {
	$results = perform_basic_search($query); 
	output_search_results($results, $startval, $limit);
}
if ($action=="album_detail") {
	$results = perform_album_search($album);
	output_search_results($results, $startval, $limit);
}
if ($action=="advanced_search_form") {
	output_advanced_search();
}

if ($action=="browse_albums_form") {
	output_browse_albums();
}

if ($action=="browse") {
	$results = perform_browse_search($genre, $beginswith);
	output_search_results($results, $startval, $limit);
}
if ($action=="advanced_search") {
	$results = perform_advanced_search($title, $artist, $composer,$conductor, $upc, $albumsorsongs);
	output_search_results($results, $startval, $limit);
}
if ($action=="suggestion_form") {
	output_suggestion_form($thanks);
}
if ($action=="submit_suggestion") {
	submit_suggestion($upc, $comments);
}

if ($action=="") {
?>
<Table width=500px><tr><Td class='headtext'>Welcome to LAMP. To get started, use the search box above to find music and click "[add song]" or "[add album]". To listen, tune your TV to
the MIT Cable channel listed next to your name. Please e-mail <a href="mailto:lamp@mit.edu">lamp@mit.edu</a> with any questions.</td></tr></table>
<?
}
?>
</div>
</td>
</tr>
</table>
<?
output_footer();
?>
