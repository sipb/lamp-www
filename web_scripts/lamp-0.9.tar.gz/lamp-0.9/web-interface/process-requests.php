<?
require_once("lamp.php");
db_connect();
switch($req)
{
	
	case "suggestion":
		submit_suggestion($upc, $comments);
		break;
	case "enqueue": 
		process_enqueue(get_username(), $music_type, $music_id);		
		break;

	case "give_up_channel": 
		process_give_up_channel(get_username());
		break;

	case "get_channel": 
		process_get_channel(get_username());
		break;

	case "control_playback": 
		process_control_playback_request(get_username(), $control, $coord);
		break;
	case "beginning_of_song": 
		process_control_playback_request(get_username(), $control, $coord);
		break;
	
        case "clear_playlist":
                process_clear_playlist_request(get_username());
                break;
        case "swap_songs":
                process_swap_songs_request(intval($pos1),$pos2, get_username());
                break;
        case "delete_song":
                process_delete_song_request(intval($pos), get_username());
                break;

	case "play_playlist":
		process_play_playlist(get_username());
		break;	

	case "skip_to_spot":
		process_control_playback_request(get_username(), $control, $coord);
                break;

	
/*
	case "album_playback":
		process_album_playback_request(get_username(), intval($album_id));
		break;
	case "song_playback":
		process_song_playback_request(get_username(), intval($song_id),$song_ids);
		break;
	case "clear_playlist":
		process_clear_playlist_request(get_username());
		break;
	case "swap_songs":
		process_swap_songs_request(intval($pos1),$pos2);
		break;
	case "delete_song":
		process_delete_song_request(intval($pos));
		break;	
	case "set_prefs":
		process_set_prefs_request(get_username(),intval($use_jukebox_queue));
		break;
	case "playback_hold":
		process_playback_hold_request(get_username());
		break;
	case "playback_resume":
		process_playback_resume_request(get_username());
		break;
	case "control_playback":
		process_control_playback_request(get_username(), $control,$coord);
		break;
*/

}
Header("Location:$location");

?>
