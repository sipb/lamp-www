#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <sched.h>
#include <math.h>
#include <malloc.h>

#include <sys/io.h>

#include <sys/ioctl.h>
#include <linux/rtc.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/un.h>

#include <sys/poll.h>

#include <sys/mman.h>

extern "C" {
#include <ppm.h>
}

#include "display.h"

const int WIDTH = 640;
const int HEIGHT = 480;

void draw_demotext( LampDisplay *mydisplay );
void recode( char *string );

pixel **lampback_array;
FILE *lampback;
int image_rows, image_cols;
pixval maxval;

void reread( void )
{
  if ( (lampback = fopen( "lampback.ppm", "r" )) == NULL ) {
    perror( "fopen" );
    exit( 1 );
  }

  lampback_array = ppm_readppm( lampback, &image_cols, &image_rows, &maxval );

  fclose( lampback );

  if ( (image_cols != WIDTH) || (image_rows != HEIGHT) ) {
    fprintf( stderr, "Bad image size.\n" );
    exit( 1 );
  }
}

int main( int argc, char *argv[] )
{
  LampDisplay *mydisplay;

  ppm_init( &argc, argv );

  if ( (lampback_array = ppm_allocarray( WIDTH, HEIGHT )) == NULL ) {
    perror( "ppm_allocarray" );
    exit( 1 );
  }

  reread();

  mydisplay = new LampDisplay( WIDTH, HEIGHT );
  /* check depth */
  printf( "Bits per pixel: %i\n", mydisplay->bits_per_pixel );
  if ( mydisplay->bits_per_pixel != 16 ) {
    fprintf( stderr, "Sorry, we don't support that bit depth.\n" );
    exit( 1 );
  }

  mydisplay->ppm_import( lampback_array, 1.0 );
  mydisplay->update();

  draw_demotext( mydisplay );

  ppm_freearray( lampback_array, HEIGHT );

  if ( fclose( lampback ) ) {
    perror( "fclose" );
    exit( 1 );
  }
}

void draw_demotext( LampDisplay *mydisplay )
{
  Font newfont, bigfont;
  XFontStruct *newfontstruct, *bigfontstruct;
  int rtc;
  struct timeval thetime, lasttime;
  struct timezone useless;

  struct sched_param myparams;

  int realtime = atoi(getenv("REALTIME"));

  int mysocket = socket( PF_UNIX, SOCK_DGRAM, 0 );

  struct pollfd ufds[ 2 ];

  struct sockaddr_un mysockaddr;

  mysockaddr.sun_family = AF_UNIX;
  strcpy( mysockaddr.sun_path, "/tmp/lamp-display-socket" );
  
  unlink( "/tmp/lamp-display-socket" );

  umask( 0 );

  if ( bind( mysocket, (struct sockaddr *) (&mysockaddr), sizeof( mysockaddr )  ) != 0 ) {
    perror( "bind" );
    exit( 1 );
  }

  if ( realtime ) {
    myparams.sched_priority = sched_get_priority_max( SCHED_FIFO );
    if ( sched_setscheduler( 0, SCHED_FIFO, &myparams ) == -1 ) {
      perror( "setscheduler" );
      exit( 1 );
    }
    
    if ( mlockall( MCL_CURRENT | MCL_FUTURE ) != 0 ) {
      perror( "mlockall" );
      exit( 1 );
    }

    rtc = open( "/dev/rtc", O_RDONLY );
    if (rtc ==  -1) {
      perror("/dev/rtc");
      exit(errno);
    }
    
    ioctl(rtc, RTC_IRQP_SET, 8192);
    ioctl(rtc, RTC_PIE_ON, 0);
    
    if ( iopl( 3 ) != 0 ) {
      perror( "iopl" );
      exit( 1 );
    }
  }

  char skyline[1024] = "";

  char chan_strings[16][1024];
  char save_strings[16][1024];
  char username[16][1024];
  char chan_info[16][1024];
  char save_username[16][1024];
  char timing[16][1024];
  char save_timing[16][1024];
  float opacity[16];
  int fade[16];
  time_t timeout[16];

  for ( int j = 0; j < 16; j++ ) {
    opacity[ j ] = 1.0;
    fade[ j ] = 0;
    timeout[ j ] = 0;
    strncpy( chan_strings[ j ], "", 1024 );
    strncpy( save_username[ j ], "", 1024 );
    strncpy( chan_info[ j ], "", 1024 );
    strncpy( username[ j ], "", 1024 );
    strncpy( save_username[ j ], "", 1024 );
    strncpy( timing[ j ], "", 1024 );
    strncpy( save_timing[ j ], "", 1024 );
  }

  int string_lengths[16];
  int save_lengths[16];
  int info_lengths[16];
  int timing_lengths[16];
  int save_timing_lengths[16];

  int margin = 85;

  char demostring[200];

  Pixmap mypixmap, virgin_screen, demo2pixmap, myrealpixmap;
  int demowidth;
  int i = 0;


  XGCValues myvalues;
  myvalues.background = ((205 << 8) & 63488) | ((219 << 3) & 2016)
	  | (240 >> 3);
  XChangeGC( mydisplay->mydisplay, mydisplay->mygc, GCBackground, &myvalues );

  newfont = XLoadFont( mydisplay->mydisplay,
		       "-bluesky-cmss17-medium-r-normal--0-200-0-0-p-0-adobe-fontspecific" );
  newfontstruct = XQueryFont( mydisplay->mydisplay, newfont );

  bigfont = XLoadFont( mydisplay->mydisplay,
		       "-bluesky-cmss17-medium-r-normal--0-400-0-0-p-0-adobe-fontspecific" );
  bigfontstruct = XQueryFont( mydisplay->mydisplay, bigfont );

  int skylinewidth = 0;
  float skylineopacity = 1.0;
  char skylinefade = 0;

  XSetFont( mydisplay->mydisplay, mydisplay->mygc, newfont );

  snprintf( demostring, 200, "63:%c", 160 );

  demowidth = XTextWidth( newfontstruct, demostring, strlen( demostring ) );

  mypixmap = XCreatePixmap( mydisplay->mydisplay, mydisplay->mywindow, mydisplay->width,
			    subheight, 16 );

  myrealpixmap = XCreatePixmap( mydisplay->mydisplay, mydisplay->mywindow, mydisplay->width,
				subheight, 16 );

  demo2pixmap = XCreatePixmap( mydisplay->mydisplay, mydisplay->mywindow,
			       mydisplay->width - demowidth - margin, subheight, 16 );

  virgin_screen = XCreatePixmap( mydisplay->mydisplay, mydisplay->mywindow, mydisplay->width,
				 subheight, 16 );

  myvalues.foreground = myvalues.background;
  XChangeGC( mydisplay->mydisplay, mydisplay->mygc, GCForeground, &myvalues );
  XFillRectangle( mydisplay->mydisplay, mydisplay->mywindow, mydisplay->mygc, 0, mydisplay->height - subheight,
		  mydisplay->width, subheight );

  XCopyArea( mydisplay->mydisplay, mydisplay->mywindow, virgin_screen, mydisplay->mygc, 0,
	     mydisplay->height - subheight, mydisplay->width, subheight, 0, 0 );
  XCopyArea( mydisplay->mydisplay, virgin_screen, myrealpixmap, mydisplay->mygc, 0, 0,
	     mydisplay->width, subheight, 0, 0 );
  XCopyArea( mydisplay->mydisplay, virgin_screen, mypixmap, mydisplay->mygc, 0, 0,
	     mydisplay->width, subheight, 0, 0 );
  XCopyArea( mydisplay->mydisplay, virgin_screen, demo2pixmap, mydisplay->mygc, 0, 0,
	     mydisplay->width - demowidth - margin, subheight, 0, 0 );

  ufds[ 0 ].fd = mysocket;
  if ( realtime ) {
    ufds[ 1 ].fd = rtc;
  } else {
    ufds[ 1 ].fd = STDIN_FILENO;
  }

  for ( int k = 0; k < 16; k++ ) {
    string_lengths[ k ] = XTextWidth( newfontstruct, chan_strings[ k ], strlen( chan_strings[ k ] ) );
    save_lengths[ k ] = XTextWidth( newfontstruct, save_strings[ k ], strlen( save_strings[ k ] ) );
    info_lengths[ k ] = XTextWidth( newfontstruct, chan_info[ k ], strlen( chan_info[ k ] ) );
    timing_lengths[ k ] = XTextWidth( newfontstruct, timing[ k ], strlen( timing[ k ] ) );
    save_timing_lengths[ k ] = XTextWidth( newfontstruct, save_timing[ k ], strlen( save_timing[ k ] ) );
  }

  myvalues.foreground = 0;
  XChangeGC( mydisplay->mydisplay, mydisplay->mygc, GCForeground, &myvalues );

  for ( int j = 63; j <= 77; j++ ) {
    snprintf( demostring, 200, "%d:%c", j, 160 );
    XDrawImageString( mydisplay->mydisplay, mypixmap, mydisplay->mygc,
		      50, 18 * (j - 62), demostring, strlen( demostring ) );
  }

  gettimeofday( &lasttime, &useless );

  while( 1 ) {
    time_t the_time = time( NULL );
    i--;

    myvalues.foreground = myvalues.background;
    XChangeGC( mydisplay->mydisplay, mydisplay->mygc, GCForeground, &myvalues );
    XFillRectangle( mydisplay->mydisplay, demo2pixmap, mydisplay->mygc, 0, 0,
		    mydisplay->width - demowidth - margin, subheight );

    if ( skylinefade == -1 ) {
      if ( skylineopacity > 0.0 ) {
	mydisplay->ppm_import( lampback_array, skylineopacity );
	mydisplay->update();
      } else {
	XSetFont( mydisplay->mydisplay, mydisplay->mygc, bigfont );
	float tmpopac = -skylineopacity;
	if ( tmpopac > 1.0 ) {
	  tmpopac = 1.0;
	}
	myvalues.foreground = color( 0, 0, 0, tmpopac );
	XChangeGC( mydisplay->mydisplay, mydisplay->mygc, GCForeground, &myvalues );
	XDrawString( mydisplay->mydisplay, mydisplay->mywindow, mydisplay->mygc,
		     320 - skylinewidth/2, 100,
		     skyline, strlen( skyline ) );
	XSetFont( mydisplay->mydisplay, mydisplay->mygc, newfont );
      }
      skylineopacity -= 0.03;
      if ( skylineopacity < -8.0 ) {
	skylineopacity = -8.0;
	skylinefade = 1;
      }
    } else if ( skylinefade == 1 ) {
      if ( skylineopacity > 0.0 ) {
	mydisplay->ppm_import( lampback_array, skylineopacity );
	mydisplay->update();
      } else {
	XSetFont( mydisplay->mydisplay, mydisplay->mygc, bigfont );
	float tmpopac = -skylineopacity;
	if ( tmpopac > 1.0 ) {
	  tmpopac = 1.0;
	}
	myvalues.foreground = color( 0, 0, 0, tmpopac );
	XChangeGC( mydisplay->mydisplay, mydisplay->mygc, GCForeground, &myvalues );
	XDrawString( mydisplay->mydisplay, mydisplay->mywindow, mydisplay->mygc,
		     320 - skylinewidth/2, 100,
		     skyline, strlen( skyline ) );
	XSetFont( mydisplay->mydisplay, mydisplay->mygc, newfont );
      }
      skylineopacity += 0.03;
      if ( skylineopacity > 1.0 ) {
	skylineopacity = 1.0;
	skylinefade = 0;
      }
    }

    for ( int j = 0; j < 16; j++ ) {
      int length = timing_lengths[ j ] + string_lengths[ j ] + info_lengths[ j ];

      if ( fade[ j ] == 1 ) {
	opacity[ j ] += 0.03;

	if ( opacity[ j ] > 1.0 ) {
	  opacity[ j ] = 1.0;
	  fade[ j ] = 0;
	}
      } else if ( fade[ j ] == -1 ) {
	opacity[ j ] -= 0.03;

	if ( opacity[ j ] < 0.0 ) {
	  opacity[ j ] = 0.0;
	  fade[ j ] = 1;
	  strcpy( chan_strings[ j ], save_strings[ j ] );
	  strcpy( timing[ j ], save_timing[ j ] );
	  string_lengths[ j ] = save_lengths[ j ];
	  timing_lengths[ j ] = save_timing_lengths[ j ];
	  strcpy( username[ j ], save_username[ j ] );
	  if ( strcmp( username[ j ], "" ) == 0 ) {
	    strcpy( chan_info[ j ], " " );
	  } else {
	    sprintf( chan_info[ j ], "(%s, 00m) ", username[ j ] );
	  }
	  recode( chan_info[ j ] );
	  info_lengths[ j ] =  XTextWidth( newfontstruct,
					   chan_info[ j ],
					   strlen( chan_info[ j ] ) );
	}
      }

      time_t diff = timeout[ j ] - the_time;
      if ( diff < 0 ) { diff = 0; }
      diff += 59;
      diff /= 60;

      if ( fade[ j ] != -1 ) {
	if ( strcmp( username[ j ], "" ) == 0 ) {
	  strcpy( chan_info[ j ], " " );
	} else {
	  sprintf( chan_info[ j ], "(%s, %dm) ", username[ j ], (int)diff );
	}
	recode( chan_info[ j ] );
      }

      if ( length > mydisplay->width - demowidth - margin ) {
	double speedbump = length / (1.5*479.52);
	myvalues.foreground = color( 160, 32, 54, opacity[ j ] );
	XChangeGC( mydisplay->mydisplay, mydisplay->mygc, GCForeground, &myvalues );
	
	XDrawString( mydisplay->mydisplay, demo2pixmap, mydisplay->mygc,
		     int(i*speedbump) % length, 18 * (j + 1),
		     timing[ j ], strlen( timing[ j ] ) );
	XDrawString( mydisplay->mydisplay, demo2pixmap, mydisplay->mygc,
		     (int(i*speedbump) % length) + length, 18 * (j + 1),
		     timing[ j ], strlen( timing[ j ] ) );
	
	if ( j % 2 ) {
	  myvalues.foreground = color( 0, 0, 0, opacity[ j ] );
	} else {
	  myvalues.foreground = color( 0x20, 0x20, 0x90, opacity[ j ] );
	}
	XChangeGC( mydisplay->mydisplay, mydisplay->mygc, GCForeground, &myvalues );

	XDrawString( mydisplay->mydisplay, demo2pixmap, mydisplay->mygc,
		     (int(i*speedbump) % length) + timing_lengths[ j ], 18 * (j + 1),
		     chan_strings[ j ], strlen( chan_strings[ j ] ) );
	XDrawString( mydisplay->mydisplay, demo2pixmap, mydisplay->mygc,
		     ((int(i*speedbump) % length) + length) + timing_lengths[ j ], 18 * (j + 1),
		     chan_strings[ j ], strlen( chan_strings[ j ] ) );

	myvalues.foreground = color( 96, 96, 96, opacity[ j ] );

	XChangeGC( mydisplay->mydisplay, mydisplay->mygc, GCForeground, &myvalues );

	XDrawString( mydisplay->mydisplay, demo2pixmap, mydisplay->mygc,
		     (int(i*speedbump) % length) + timing_lengths[ j ]+ string_lengths[ j ], 18 * (j + 1),
		     chan_info[ j ], strlen( chan_info[ j ] ) );
	XDrawString( mydisplay->mydisplay, demo2pixmap, mydisplay->mygc,
		     (int(i*speedbump) % length) + length + timing_lengths[ j ] + string_lengths[ j ], 18 * (j + 1),
		     chan_info[ j ], strlen( chan_info[ j ] ) );
      } else {
	myvalues.foreground = color( 160, 32, 54, opacity[ j ] );
	XChangeGC( mydisplay->mydisplay, mydisplay->mygc, GCForeground, &myvalues );
	
	XDrawString( mydisplay->mydisplay, demo2pixmap, mydisplay->mygc,
		     0, 18 * (j + 1),
		     timing[ j ], strlen( timing[ j ] ) );

	if ( j % 2 ) {
	  myvalues.foreground = color( 0, 0, 0, opacity[ j ] );
	} else {
	  myvalues.foreground = color( 0x20, 0x20, 0x90, opacity[ j ] );
	}
	XChangeGC( mydisplay->mydisplay, mydisplay->mygc, GCForeground, &myvalues );

	XDrawString( mydisplay->mydisplay, demo2pixmap, mydisplay->mygc,
		     timing_lengths[ j ], 18 * (j + 1),
		     chan_strings[ j ], strlen( chan_strings[ j ] ) );
	myvalues.foreground = color( 96, 96, 96, opacity[ j ] );
	XChangeGC( mydisplay->mydisplay, mydisplay->mygc, GCForeground, &myvalues );

	XDrawString( mydisplay->mydisplay, demo2pixmap, mydisplay->mygc,
		     timing_lengths[ j ] + string_lengths[ j ], 18 * (j + 1),
		     chan_info[ j ], strlen( chan_info[ j ] ) );
      }
    }

    XCopyArea( mydisplay->mydisplay, demo2pixmap, mypixmap, mydisplay->mygc, 0, 0,
	       mydisplay->width - demowidth - margin, subheight, 50 + demowidth, 0 );

    unsigned long data;
    while( 1 ) {
      unsigned long difference;
      char packet[ 1024 ];

      ufds[ 0 ].events = POLLIN;
      ufds[ 1 ].events = POLLIN;

      poll( ufds, 2, 10 );

      if ( ufds[ 0 ].revents & POLLIN ) {
	memset( packet, 0, 1024 );
	read( mysocket, packet, 1024 );

	if ( packet[ 0 ] == 0 ) { /* song update */
	  int chan = packet[ 1 ];
	  if ( (chan < 63) || (chan > 78) ) {
	    fprintf( stderr, "Bad chan %d\n", chan );
	    exit( 1 );
	  }

	  memset( save_strings[ chan - 63 ], 0, 1024 );
	  strncpy( save_strings[ chan - 63 ], packet + 2, 1022 );
	  recode( save_strings[ chan - 63 ] );
	  save_lengths[ chan - 63 ] = XTextWidth( newfontstruct,
						  save_strings[ chan - 63 ],
						  strlen( save_strings[ chan - 63 ] ) );

	  if ( strcmp( save_strings[ chan - 63 ], chan_strings[ chan - 63 ] ) != 0 ) {
	    fade[ chan - 63 ] = -1;
	  }
	} else if ( packet [ 0 ] == 1 ) { /* timing update */
	  int chan = packet[ 1 ];
	  if ( (chan < 63) || (chan > 78) ) {
	    fprintf( stderr, "Bad chan %d\n", chan );
	    exit( 1 );
	  }
	  if ( fade[ chan - 63 ] != -1 ) {
	    memset( timing[ chan - 63 ], 0, 1024 );
	    strncpy( timing[ chan - 63 ], packet + 2, 1022 );
	    recode( timing[ chan - 63 ] );
	    strcpy( save_timing[ chan - 63 ], timing[ chan - 63 ] );
	    save_timing_lengths[ chan - 63 ] = timing_lengths[ chan - 63 ]
	      = XTextWidth( newfontstruct,
			    timing[ chan - 63 ],
			    strlen( timing[ chan - 63 ] ) );
	  } else {
	    memset( save_timing[ chan - 63 ], 0, 1024 );
	    strncpy( save_timing[ chan - 63 ], packet + 2, 1022 );
	    recode( save_timing[ chan - 63 ] );
	    save_timing_lengths[ chan - 63 ] = XTextWidth( newfontstruct,
							   save_timing[ chan - 63 ],
							   strlen( save_timing[ chan - 63 ] ) );
	  }
	} else if ( packet [ 0 ] == 2 ) { /* info update */
	  int chan = packet[ 1 ];
	  if ( (chan < 63) || (chan > 78) ) {
	    fprintf( stderr, "Bad chan %d\n", chan );
	    exit( 1 );
	  }

	  memset( save_username[ chan - 63 ], 0, 1024 );
	  strncpy( save_username[ chan - 63 ], packet + 2, 1022 );
	  recode( save_username[ chan - 63 ] );

	  if ( strcmp( save_username[ chan - 63 ], username[ chan - 63 ] ) != 0 ) {
	    fade[ chan - 63 ] = -1;
	  }
	} else if ( packet [ 0 ] == 3 ) { /* timeout update */
	  int chan = packet[ 1 ];
	  if ( (chan < 63) || (chan > 78) ) {
	    fprintf( stderr, "Bad chan %d\n", chan );
	    exit( 1 );
	  }

	  memcpy( &(timeout[ chan - 63 ]), &(packet[ 2 ]), sizeof( time_t ) );
	} else if ( packet[ 0 ] == 4 ) { /* skyline */
	  memset( skyline, 0, 1024 );
	  strncpy( skyline, packet + 1, 1023 );
	  recode( skyline );
	  skylinewidth = XTextWidth( bigfontstruct, skyline, strlen( skyline ) );
	  skylinefade = -1;
	  skylineopacity = 1.0;
	} else if ( packet[ 0 ] == 5 ) { /* reread */
	  reread();
	} else {
	  fprintf( stderr, "Bad packet type %d\n", packet[ 0 ] );
	  exit( 1 );
	}
      }

      if ( realtime ) {
	if ( ufds[ 1 ].revents & POLLIN ) {
	  read( rtc, &data, sizeof( unsigned long ) );
	}
      }

      gettimeofday( &thetime, &useless );
      difference = 1000000 * (thetime.tv_sec - lasttime.tv_sec) +
	(thetime.tv_usec - lasttime.tv_usec);
      
      if ( difference > 16500 ) {
	break;
      }
    }

    if ( realtime ) {
      while( 1 ) {
	if( (inb( 0x3da ) & 8) ) break;
      }
      while( 1 ) {
	if( !(inb( 0x3da ) & 8) ) break;
      }
    }
    
    gettimeofday( &lasttime, &useless );

    XCopyArea( mydisplay->mydisplay, mypixmap, mydisplay->mywindow, mydisplay->mygc, 0, 0,
	       mydisplay->width, subheight, 0, mydisplay->height - subheight );
    XFlush( mydisplay->mydisplay );

    if ( i % 1000 ) {
      XEvent ev;
      while(XPending(mydisplay->mydisplay)) XNextEvent(mydisplay->mydisplay, &ev);
    }
  }

  int x, y, z;
  mydisplay->getclick( &x, &y, &z );

  XFreePixmap( mydisplay->mydisplay, mypixmap );
}

void recode( char *string )
{
  char *ptr;
  while ( (ptr = strchr( string, ' ' )) ) {
    *ptr = 160;
  }

  while ( (ptr = strchr( string, '_' )) ) {
    *ptr = 160;
  }
}
