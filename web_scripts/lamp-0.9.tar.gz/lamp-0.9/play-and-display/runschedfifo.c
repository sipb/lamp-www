#include <sched.h>
#include <stdio.h>
#include <unistd.h>

int main( int argc, char **argv )
{
  struct sched_param myparams;

  myparams.sched_priority = sched_get_priority_max( SCHED_FIFO );
  if ( sched_setscheduler( 0, SCHED_FIFO, &myparams ) == -1 ) {
    perror( "setscheduler" );
    exit( 1 );
  }

  return execve( argv[ 1 ], &(argv[ 1 ]), NULL );
}
