<?
include("lamp.php");
db_connect();

if ($password != "_password_")
	exit();

if ($action=="end of song")
{process_song_done_callback($channel);}
else if ($action=="user time is up")
{process_user_cutoff_callback($channel);}

// Header("location:$location");

?>
