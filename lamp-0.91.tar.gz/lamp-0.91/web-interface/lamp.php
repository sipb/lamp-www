<?
require_once("Music.php");

function getmicrotime(){ 
    list($usec, $sec) = explode(" ",microtime()); 
    return ((float)$usec + (float)$sec); 
    } 

function get_username()
{
$u =  $_SERVER[SSL_CLIENT_EMAILADDRESS];
$u = ereg_replace("@MIT.EDU","",$u);
return $u;
}

function db_query($s) {
#	echo "s: $s";
	return mysql_query($s);
}

function db_fetch_array($s) {
	return mysql_fetch_array($s);
}

function db_numrows($s) {
	return mysql_numrows($s);
}

function output_header($style="")
{
  include("header.php");
}

function output_footer() {
	include("footer.php");
}
function db_connect()
{
        $db = mysql_connect("localhost","lamp","_password_"); mysql_select_db("lamp",$db);

}
function now_playing($channel)
{
        $q =db_query("select now_playing from channels where channel_number=$channel");
        if (db_numrows($q) > 0) {
	$q = db_fetch_array($q);
        return $q[now_playing];
	}

	return "";
}

function output_suggestion_form($thanks = "") {
if ($thanks) {
	echo "<div class=\"headtext\">Thank you for your suggestion! We will include your CD in our next purchase.</div>Feel free to make more suggestions below.<div class=\"hr\"><br><br>";
}

?>
<div class="headtext">Request Music</div><br>
To request a CD for LAMP, please submit its UPC (included in album listings at <a href="http://music.barnesandnoble.com/index.asp?">Barnes & Noble.com</a>).<br><br>

<form action="process-requests">
<input type="hidden" name="location" value="/?action=suggestion_form&thanks=1">
<input type="hidden" name="req" value="suggestion">
UPC: <input type="text" name="upc"><br>
<br>
Comments (optional):<br>
<textarea name="comments" rows="5" cols="35" wrap="soft"></textarea>
<br><br>
<input type="submit" value="submit request">
</form>
<?
}

function submit_suggestion($upc, $comments) {
	if ($upc != "" || $comments != "")  {
	db_query("insert into suggestions (upc, username, comments) values ('$upc', '".get_username()."', '$comments	')");

	}	
}

function output_browse_albums() {
	?>
	<form>
	<div class="headtext">Browse Music</div>
	<br>
	Genre: 
	<select name="genre">	
	<option value="">All</option>
	<?
	$genres = db_query("select distinct album_genre from albums order by album_genre asc");
	while ($g = db_fetch_array($genres)){
		echo "<option value=\"$g[album_genre]\">$g[album_genre]</option>\n";
	}
	?>
	</select>
	<br>
	Artist begins with:
	<select name="beginswith">
	<option value="">All</option>
	<?
	for ($j = 'A'; $j < 'Z'; $j++) {
		echo "<option value=\"$j\">$j</option>\n";
	}
	?>
	</select>
	<br>
	<input type="submit" value="browse" name="action">
	</form>
<?
}

function output_advanced_search() {
?>
<form>
<div class="headtext">Advanced Search</div><br>
<table><tr>
<td class="search_cell">
Title:</td><td  class="search_cell"> <input type="text" name="title"></td></tr>
<tr><td class="search_cell">Artist:</td><td class="search_cell"> <input type="text" name="artist"></td></tr>
<tr><td class="search_cell">Composer:</td><td class="search_cell"> <input type="text" name="composer"></td></tr>
<tr><td class="search_cell">Conductor:</td><td class="search_cell"> <input type="text" name="conductor"></td></tr>
<tr><td class="search_cell">UPC:</td><td class="search_cell"> <input type="text" name="upc"></td></tr>
<tr><td>Find:</td><td> 
<input type="radio" name="albumsorsongs" value="albums">Albums
<input type="radio" name="albumsorsongs" value="songs">Songs
<input type="radio" name="albumsorsongs" value="both" CHECKED>Both
</td></tr>

</table>
<input type="hidden" name="action" value="advanced_search">
<input type="submit" value="find music">
</form>
<?
}


function output_now_playing() {
$active_channels = db_query("select * from channels");

echo "<Div class=\"playlist_box\" id=\"color0\"><b>Now playing:</b></div>

<div class=\"playlist_box\">";

while ($chan=db_fetch_array($active_channels))
{
        $song = new Music("song", $chan[now_playing]);
        $user = $chan[username];
	$aid = $song->get_album();
	$aid = $aid->music_id;
        $line =  "Channel <span id=\"channelnum\">$chan[channel_number]</span>: <span id=\"extra\">".
        (($song->music_id=="")?(($user != "")?"reserved":"available"):"<a href=\"?action=album_detail&album=".$aid."\">".$song->get_title()."</a>").
 	"</span>".

       (($user != "")?" [$user]":"").
	" </div><div class=\"hr\">";

	echo "<div class=\"now_playing\" id=\"color".(($user!="")?"1":"0")."\"> $line </div>";
	$i++;
}
echo "</div>";

}

function output_controlbox($username) {
$chan = get_channel_by_user($username);

?>

<div class="playlist_box">

<b>Welcome, <? echo $username; ?>.</b><br>
<nobr>Your LAMP Channel:

<?
	$chan = get_channel_by_user($username);
	$free_channels = db_numrows(get_free_channels());
	if ($chan == 0 && $free_channels == 0) {
		echo "<em>none available</em> (<a href=\"process-requests.php?req=play_playlist&location=".get_location()."\">try again</a>)";
	} else if ($chan == 0 && $free_channels > 0 && next_song_in_playlist($username)=="") {
		echo "<em>none</em>";
	} else if ($chan == 0 && $free_channels > 0) {
		echo "<em>none</em> (<a href=\"process-requests.php?req=play_playlist&location=".get_location()."\">request</a>)";
	} else  if ($chan != 0 ) {
		echo "<b>$chan</b> (<a href=\"process-requests.php?req=give_up_channel&location=".get_location()."\">give back</a>)";
	}

?> 
</nobr>
<?
if ($chan != 0 && now_playing($chan) != "") {
$song = new Music("song",now_playing($chan));
$album = $song->get_album();
?>
<div class="control_function" id="color1">
<?echo "<a href='?action=album_detail&album=".$album->music_id."'><em>".$song->get_title(0)."</em></a><br>"; ?>
<br>[ <a href="process-requests.php?req=control_playback&control=beginning_of_song&location=<?echo get_location();?>">beginning of song</a>

 | <a href="process-requests.php?req=control_playback&control=next_song&location=<?echo get_location();?>">next song</a> ]<br>
[ <a href="process-requests.php?req=control_playback&control=play&location=<?echo get_location();?>">play</a> |  <a href="process-requests.php?req=control_playback&control=pause&location=<?echo get_location();?>">pause</a> ]
<br>
<span class="small_numbers">
skip: <?
for ($i = 20; $i <= 80; $i+= 20) {
	echo "<a href=\"process-requests.php?req=control_playback&control=skip_to_spot&coord=$i&location=".get_location()."\">$i%</a> ".(($i != 80)?"... ":"")."";
}
?>
</span>
</div>
<?
}
?>
</div>

<?

}

function get_location() {
	return urlencode($_SERVER[REQUEST_URI]);
}

function get_playlist($username)
{
        if ($username=="unset"){$username=get_username();}
        return db_query("select * from playlists where username='$username' order by queue_position asc");
}


function output_playlist($username) {

$playlist = get_playlist($username);
        $i = 0;
        $songs = array();
        $positions = array();
       while ($elt=db_fetch_array($playlist))
        {
                $positions[$i]=$elt[queue_position];
                $songs[$i]= new Music("song", $elt[track_id]);
                $i++;
        }
if (sizeof($songs) > 0) {
?>
<br>
<div class="playlist_box">
<b>Your playlist:</b> <?
if (sizeof($songs) > 0) {
?>
<A href="process-requests.php?req=clear_playlist&location=<? echo get_location();?>"><span id="color0">(erase playlist)</span></a>
<?
}
?><br>
<table class="playlist_table">

<?
       function generate_link($a,$b,$dir)
        {
                $current_loc=get_location();
                return "<a href=\"process-requests.php?req=swap_songs&pos1=$a&pos2=$b&location=$current_loc\">$dir</a>";
        }

	for ($i = 0; $i < sizeof($songs); $i++) {
?>
<tr class="playlist_line" id="color1">
<td class="vspace" id="hspace">
<? echo ($i+1) . ". " . "<a href='?action=album_detail&album=";  
$a = $songs[$i]->get_album();
		echo $a->music_id;
echo		 "'>" . 
		$songs[$i]->get_title(). "</a>";

?>
</td><td class="vspace">
<nobr class="playlist_functions">
<?
echo generate_link($positions[$i-1],$positions[$i], "up<br>");
echo generate_link($positions[$i],$positions[$i+1], "down<br>");
?>
</td>
<td class="vspace">
<nobr class="playlist_functions">

<?

echo generate_link($positions[$i],"top", "top<br>");
echo "<a href=\"process-requests.php?req=delete_song&pos=$positions[$i]&location=".get_location()."\">delete</a>";

?>
</td>
</td>

</tr>
<tr><td colspan="2"><div class="hr"></td></tr>
<?
	}
?>
</table>
</div>
<?
}

}


function output_search_results($queries, $startval=0, $limit=0){
global $begintime;
$t0 = getmicrotime();
	$beginsearchtime  = getmicrotime();
#	echo "time to begin search_results: " . ($beginsearchtime - $begintime);
if ($startval=="") { $startval = 0; }
if ($limit == 0 ) { $limit = 30; }

$numalbums = 0;
$numsongs = 0;
$i = 0;
$maxpages = 100;
$biglimit = $maxpages * $limit;
if ($queries[albums] != ""){

$numalbums = db_numrows(db_query($queries[albums] . " limit $startval,$biglimit"));
$albums = db_query($queries[albums] . " limit $startval,$limit");

while ($r = db_fetch_array($albums)) {
	$results[$i++] = new Music("album", $r[id]);
}

}
	$beginsearchtime  = getmicrotime();
#	echo "time to albums created: " . ($beginsearchtime - $begintime);

if ($queries[songs] != "") {

	$songs = db_query($queries[songs] . " limit $startval,$limit");
	$beginsearchtime  = getmicrotime();


#	echo "time to songs queried: " . ($beginsearchtime - $begintime);
	$numsongs = db_numrows(db_query($queries[songs] . " limit $startval,$biglimit"));
	
	$beginsearchtime  = getmicrotime();
#	echo "time to songs counted: " . ($beginsearchtime - $begintime);

while ($r = db_fetch_array($songs)) {
	$results[$i++] = new Music("song", $r[id]);
}

}
	$beginsearchtime  = getmicrotime();
#	echo "time to songs created: " . ($beginsearchtime - $begintime);

$firstresultnumber = 1 + $startval;
$total = max($numalbums, $numsongs);
$start = "<br><table><tr>";
$albumcell = "<td id=\"color0\" class=\"searchresult_table\"><b>Discs ($numalbums found)</b><br><br>";
$songcell = "<td id=\"color1\" class=\"searchresult_table\"><b>Songs ($numsongs found)</b><br><br>";

?>
<div class="headtext">Music found<?
$queries[query] = trim($queries[query]);
if ($queries[query] != "") {
	echo " (".stripslashes($queries[query]) . ")";
}
echo ": ";
if ($total > $limit) {
 
$n = ceil($startval / $limit)+1;
$t = ceil($total / $limit);
echo "page $n of $t";

}
?></div>

<?

if (sizeof($results) == 0) {
	echo "No music found.";
	if ($queries[query] != "") {
		$qstring = $queries[query] . " ; " . addslashes($queries[albums]) . " ; " . addslashes($queries[songs]);
		db_query("insert into eventlog (username, info, eventcode) values ('".get_username()."', '$qstring', 'searchfailed')");
	}
} else {
		if ($t == $maxpages) {
			echo "*results exceeded limit of $maxpages pages.<br><br>";
		}
		$currnum = $firstresultnumber;
		$req = ereg_replace("&limit=$limit","",$_SERVER[REQUEST_URI]);
		$req = ereg_replace("&startval=$startval","",$req);
		$nreq = $req . "&startval=".min(($startval + $limit), $total);
		$preq = $req . "&startval=".max(($startval - $limit), 0);

		$nextprev = "";
		if ($startval > 0) {
			$needtoor = 1;
			$nextprev .= "<a href=\"$preq\">previous $limit results </a>";
		}
		
		if ($total > $limit + $startval) {	
			if ($needtoor) {$nextprev .= " | ";}
			$needtoor = 1;
			$nextprev .= "<a href=\"$nreq\">next $limit results</a>";
		}
		if ($needtoor) {
			$nextprev.= "<br>";
		}

	echo $nextprev;
	echo $start;
	$first = $results[0];


	if ($first->is_album()) {
		echo $albumcell;
	}
	else {
		echo $songcell;
		$seconds=1;
	}

}
	$beginsearchtime  = getmicrotime();
#	echo "time to start loop: " . ($beginsearchtime - $begintime);
for ($i = 0; $i < sizeof($results); $i++) {

$r = $results[$i];

if (!$r->is_album() && $seconds==0) {
	$seconds=1;
	echo "</td>".$songcell;
	$currnum = $firstresultnumber;
}

$type = $r->is_album();

?>
<span class="searchresult">

<? echo $currnum++ . ". ". $r->get_title();?>

</span><nobr>
<?


if ($r->is_album()) {
	echo "(" . $r->track_list_link() . ")";
}

?>
</nobr>
<A class="" href="<?
 echo $r->get_enqueue_link();

 ?>"><br><nobr><b>[add <?
	if ($r->is_album()) {
		echo "album";
	} else {
		echo "song";
	}
?>]</b></nobr></a>

<br>
<span class="smalltext">
<?
if ($r->work != "" && substr_count(strtolower($r->get_title()), strtolower($r->work))==0) {
	echo "Work: $r->work<br>";
} 
if ($r->get_artist() != "") {
echo "Artist: <A href=\"?artist=".$r->get_artist()."&songs=on&albums=on&action=advanced_search\">".  $r->get_artist()."</a><br>";
}
if ($r->composer != "") {
	echo "Composer: <A href=\"?composer=".$r->composer."&songs=on&albums=on&action=advanced_search\">".  $r->composer."</a><br>";
}
if ($r->conductor != "") {
	echo "Conductor: <A href=\"?conductor=".$r->conductor."&songs=on&albums=on&action=advanced_search\">".  $r->conductor."</a><br>";
}
$a = $r->get_album();
if ($a != "") {
echo "Album: <a href=\"?action=album_detail&album=".$a->music_id."\">" . $a->get_title()."</a><br>";	
}
echo "Duration: " . $r->get_time() . "<br>";

if ($r->is_album() && $queries[type]=="album") {
	echo "UPC: $r->upc <a href=\"http://service.bfast.com/bfast/click?bfmid=2181&sourceid=40776771&bfpid=$r->upc&bfmtype=music\">[buy album]</a><br>";
	if (trim($r->copyright) != ","){
		echo "Copyright: $r->copyright<br>";
	}
}


global $beginsearchtime;
$t2 = getmicrotime();
#echo "bt: $begintime; t2: $t2";
#echo "s from start of results: " . ($t2-$begintime);

?>

</span>
<br>
<?

}


echo "</td></tr></table>";
echo $nextprev;
}

function lookup_music($music) {

}

function perform_browse_search($genre, $beginswith) {

	if ($beginswith == "") {
		$ob = "album_name asc";
	} else {
		$ob = "artist_name asc, album_name asc";
	} 

	$q = ("select album_id as id from albums a where album_genre like '%$genre%' and  (artist_name like '$beginswith%' or composer like '$beginswith%') order by $ob");
  
	$results[albums] = $q;
	$results[songs] = "";
	if ($genre != "" && $beginswith != "") {
		$beginswith = ", " . $beginswith;
	}
	$results[query] = "browsing $genre".(($beginswith!="")? $beginswith:"");
	return $results;
}

function perform_advanced_search($title, $artist, $composer, $conductor, $upc, $albumsorsongs){ 
	$results = array();
		$i = 0;

	if ($albumsorsongs=="albums") {
		$albums = 1;
	} elseif ($albumsorsongs=="songs") {
		$songs = 1;
	} else {
		$albums = 1;
		$songs = 1;
	}

	if (trim($upc) != "") {
		$songs = "";
	}

	if ($albums) {
	$q = ("select album_id as id from albums a where album_name like '%$title%' and artist_name like '%$artist%' and composer like '%$composer%' and conductor like '%$conductor%' and album_upc like '%$upc%' order by album_name");

	$results[albums] = $q;
      
/*	$q = db_query($q);
        while ($r = db_fetch_array($q)) {
		$results[$i++] = new Music("album",$r[aid]);
	}
*/
	}

	if ($songs) {

	$q = ("select track_id as id from tracks s where track_name like '%$title%' and artist_name like '%$artist%' and composer like '%$composer%'  and conductor like '%$conductor%' order by track_name"); 
	$results[songs] = $q;
/*
	$q = db_query($q);
	while ($r = db_fetch_array($q)) {
		$results[$i++] = new Music("song",$r[aid]);
	
	}
*/
	}	
	
	$results[query] = "$title $artist $composer";
	return $results;	

}

function perform_album_search($query) {
	$results = array();
	//$i = 0;

	$media_id = db_fetch_array(db_query("select media_id from albums where album_id='$query'"));

	$media_id = $media_id[media_id];

	$first = 1;
	$albums = ("select album_id as id from albums where media_id='$media_id' order by volume asc");
	$results[albums] = $albums;

	$albums = db_query($albums);
/*
	while ($r = db_fetch_array($albums)) {
		
		$results[$i++] = new Music("album", $r[album_id]);		
		
		if ($first==1) {
			$first = 0;
		} else {
			$aids .= ", ";
		}

		$aids = $aids . "$r[id]";
	}
*/

	$q = ("select track_id as id from tracks s where album_id=$query order by album_id asc, track_number asc"); 

	$results[songs] = $q;
/*
	$q = db_query($q);


	while ($r = db_fetch_array($q)) {
		$results[$i++] = new Music("song",$r[aid]);
	}
*/	
	$results[type]  = "album";
	$results[query] = "";
return $results;	
	
}

function perform_basic_search($query) {
	global $begintime;
	$beginsearchtime  = getmicrotime();
#	echo "time to bs: " . ($beginsearchtime - $begintime);
	$results = array();
	$i = 0;
	$q = ("select  album_id as id from albums a where album_name like '%$query%' or artist_name like '%$query%' or composer like '%$query%' order by album_name");
	$results[albums] = $q;
/*        
	$q = db_query($q);
        while ($r = db_fetch_array($q)) {
		$results[$i++] = new Music("album",$r[aid]);
	}
	*/

	$q = ("select track_id as id from tracks s where track_name like '%$query%' or artist_name like '%$query%' or composer like '%$query%' order by track_name"); 
	$results[songs] = $q;
/*
	$q = db_query($q);
	while ($r = db_fetch_array($q)) {
		$results[$i++] = new Music("song",$r[aid]);
	
	}
	*/
	$results[query] = $query;
	$beginsearchtime  = getmicrotime();
#	echo "time to end s " . ($beginsearchtime - $begintime);
	return $results;	
}

function next_song_in_playlist($username)
{
        $q = db_query("select track_id, queue_position from playlists where username='$username' order by queue_position asc");
        if (db_numrows($q)==0)
        {return "";}


                if (!$to_return=db_fetch_array($q))
                        return "";

	return $to_return[track_id];
}


function process_play_playlist($username) {
	if ($username=="") {
		return;
	}

	$chan = get_channel_by_user($username);
	$next = next_song_in_playlist($username);
	$song = new Music("song", next_song_in_playlist($username));

	if ($chan != 0 && $song->get_title(0) != "" && now_playing($chan) == "") {
		call_lamp_play($song,$username, $chan); 	
	} else if ($chan != 0 && now_playing($chan) == "" && $song->get_title() == "") {
		// nohting left in playlist; idle 'er in 5min
	db_query("update channels set timeout_time=date_add(now(),interval 5 minute),now_playing=NULL where channel_number=$chan and date_add(now(), interval 5 minute) < end_time and timeout_time=end_time");
                $timeout = db_fetch_array(db_query("select unix_timestamp(timeout_time) as timeout from channels where channel_number=$chan"));
                $timeout = $timeout[timeout];

               exec("/usr/local/bin/lamp-channel-status $chan $username $timeout");
	

	} else if ($chan == 0 && $song->get_title() != ""){
	// find a new channel
	$free_channels = get_free_channels();
	if (db_numrows($free_channels) > 0) {
		
		$r = db_fetch_array($free_channels);
		$chan = $r[channel_number];

db_query("update channels set username='$next_user', start_time=now(), end_time=date_add(now(),interval 80 minute),timeout_time=date_add(now(),interval 80 minute) where channel_number=$chan");
		call_lamp_play($song, $username, $chan, "starting");
                }

	}
}

function get_free_channels() {
	return db_query("select * from channels where username='' order by channel_number");
}

function process_enqueue($username, $music_type, $music_id) {
	$m = new Music ($music_type, $music_id);
	if ($m == "") {
		echo "m null!";
		return -1;
		
	}
	
	$max_songs = 1000;
	$already = db_query("select track_id from playlists where username='$username'");
	if (db_numrows($already) > $max_songs) {
		return -1;
	}
	if (!$m->is_album()) {
	        db_query("insert into playlists (username, track_id) values ('$username','".$m->music_id."')");
		process_play_playlist($username);
	} else {
		// an album -- do a recursive call
		$songs = $m->get_songs();
		for ($i = 0; $i < sizeof($songs); $i++) {
			process_enqueue($username, $songs[$i]->music_type, $songs[$i]->music_id);
		}
	}
}

function playlist_is_empty($username)
{
        $to_return = db_query("select track_id from playlists where username='$username' order by queue_position asc");
        if (db_numrows($to_return)==0) return 1;
        return 0;
}

function process_clear_playlist_request($username)
{
        db_query("delete from playlists where username='$username'");
}

function process_swap_songs_request($pos1,$pos2,$username)
{
        $val1=db_query("select track_id from playlists where queue_position=$pos1 and username='$username'");
        if (db_numrows($val1) < 1)
        {
                return 1;
        }

        $val1 = db_fetch_array($val1); $val1 = $val1[track_id];

        if  ($pos2=="top" || $pos2=="bottom")
        {
                if ($pos2=="top")
                        $rows = db_query("select track_id, queue_position from playlists where username='$username' and queue_position < $pos1 order by queue_position desc");

                 else if ($pos2=="bottom")
                        $rows = db_query("select track_id, queue_position from playlists where username='$username' and queue_position > $pos1  order by queu
e_position asc");
              $position_to_change = $pos1;
                while ($row = db_fetch_array($rows))
                {
                        $new_value = $row[track_id];
                        db_query("update playlists set track_id = $new_value where queue_position=$position_to_change");
                        $position_to_change = $row[queue_position];
                }
                db_query("update playlists set track_id=$val1 where queue_position=$position_to_change");
        }
        else  // just a swap of two adjacent songs
        {
                $pos2 = intval($pos2);
                $val2=db_query("select track_id from playlists where queue_position=$pos2 and username='$username'");
                if (db_numrows($val2) < 1)
                {
                        echo "error 2";
                  return 1;
                }
                $val2=db_fetch_array($val2);
                $val2=$val2[track_id];
                db_query("update playlists set track_id=$val2 where queue_position=$pos1");
                db_query("update playlists set track_id=$val1 where queue_position=$pos2");
        }
        return 0;
}

function process_delete_song_request($pos, $username="unset")
{
        if ($username=="unset"){$username=get_username();}
       db_query("delete from playlists where queue_position=$pos and username='$username'");

        return 0;
}

function get_channel_by_user($username) {
        $q = db_query("select channel_number from channels where username='$username'");
        if (db_numrows($q)==0) {
                return 0;
	}
        else
        {
             $q = db_fetch_array($q);
             return $q[channel_number];
        }

}

function get_user_by_channel($chan) {
        $q = db_query("select username from channels where channel_number=$chan");
	$q = db_fetch_array($q);
	return $q[username];
}

function call_lamp_play($song,$username,$channel,$start_info="0")
{	
	$filename = $song->get_filename();
	$song_name = $song->get_title();
	$tvname = $song->get_tvname();

	$album = $song->get_album();
	$album_name = $album->get_title();
	db_query("update channels set username='$username', timeout_time=end_time, now_playing=".$song->music_id." where channel_number=$channel");
	db_query("delete from playlists where username='$username' and track_id=".$song->music_id);
       $timeout = db_fetch_array(db_query("select unix_timestamp(timeout_time) as timeout from channels where channel_number=$channel"));
       $timeout = $timeout[timeout];
	exec("/usr/local/bin/lamp-play \"". $filename."\" $channel $username \"$tvname\" $timeout $start_info  2>/dev/null >/dev/null& ");
}

function process_song_done_callback($chan) {
	$trackid = db_fetch_array(db_query("select now_playing from channels where channel_number = $chan"));
	$trackid = $trackid[now_playing];

	db_query("update channels set now_playing='' where channel_number=$chan");
	$user = get_user_by_channel($chan);
	if ($user == "") {	
		exec("/usr/local/bin/lamp-randomsong $chan");
	} else {		
		process_play_playlist($user);
		$intable = db_numrows(db_query("select user_id from users where username='$user'"));
		if ($intable > 0) {
			db_query("update users set num_songs_played = num_songs_played + 1, last_song_played = NOW() where username='$user'");
		} else {
			db_query("insert into users (username, num_songs_played, first_login) values ('$user', 1, NOW())");
		}
		db_query("insert into eventlog (username, info, eventcode) values ('$user', '$trackid', 'trackplayed') ");

		db_query("update songs set num_times_played=num_times_played+1 where track_id=$trackid");

	}
}


function process_user_cutoff_callback($channel)
{
        kill_playback_on_channel($channel);
}


function kill_playback_on_channel($channel)
{
	if ( $channel == 0 ) {
	return;
	}
                db_query("update channels set username='', now_playing='' where channel_number=$channel");
                // HOOK: cut playback
                exec("/usr/local/bin/lamp-stop $channel");
                exec("/usr/local/bin/lamp-channel-status $channel available");
		exec("/usr/local/bin/lamp-randomsong $channel");
}


function process_give_up_channel($username) {
	kill_playback_on_channel(get_channel_by_user($username));
}

function process_control_playback_request($username, $control, $coord="")
{
        $chan = get_channel_by_user($username);

	if ($chan==0 || now_playing($chan)=="")
        {
                return;
        }

        switch($control)
        {
        //a HOOK in each branch:
                case "beginning_of_song":
                $track_id = now_playing($chan);
		$song = new Music("song", $track_id);
                call_lamp_play($song, $username, $chan, "0");
                break;

                case "next_song":
                exec("/usr/local/bin/lamp-stop $chan");
                process_song_done_callback($chan);
                break;
                
		case "pause":
                exec("/usr/local/bin/lamp-pause $chan");
                break;
               
		case "play":
                exec("/usr/local/bin/lamp-resume $chan");
                break;

		case "skip_to_spot":
                $track_id = now_playing($chan);
		$song = new Music("song", $track_id);
                call_lamp_play($song, $username, $chan, $coord);
		break;

        }
}


?>
