<?

require_once("lamp.php");
class Music {
	
	var $music_type = "";
	var $music_id = "";
	var $artist = "";
	var $title = "";
	var $on_album = "";
	var $songs = "";
	var $filename = "";
	var $time = "";
	var $numtracks = 0;
	var $composer = "";
	var $conductor = "";
	var $copyright = "";
	var $upc = "";
	var $work = "";
	var $genre = "";

	function Music($type, $id) {
		$this->music_type = $type;
		$this->music_id = $id;
		$this->lookup_info();
	}

	function get_tvname() {
		$myalbum = $this->get_album();
		$albumgenres = array("Broadway","Soundtracks");
		$composergenres = array("Classical");
		if (in_array($myalbum->genre, $albumgenres)) {
			$extra = $myalbum->title;
		} elseif (in_array($myalbum->genre, $composergenres)) {
			if ($myalbum->composer != "") {
				$extra = $myalbum->composer;
			} else {
				$extra = $myalbum->title;
			}		

		} else {
			$extra = $this->artist;
		}
		return "$this->title ($extra)";
	}

	function get_filename() {
		if ($this->filename != "") {
			return $filename;
		}	
	        $q = db_query("select track_filename as fn from tracks where track_id=".$this->music_id);
        	$q=db_fetch_array($q);
		$this->filename = $q[fn];
		return $this->filename;
	}

	function get_title($withartist=1) {
		$to_return = $this->title;
		if ($this->title == '') {
			return $to_return; # KJW 9/18/03
		}

//		if (!$this->is_album() && $withartist) {
	//		$to_return .= " (". $this->artist . ")";
		//}
			return $to_return;

	}
	function get_artist() {
		return $this->artist;
	}
	function get_album() {
		$t = $this->on_album;

		if ($t != "") {
			return $this->on_album;
		}	
	}

	function get_time() {
			return $this->time;
	}

	function track_list_link() {
		if (!$this->is_album()) {
			
			return "";
		}
		return "<a href=\"?action=album_detail&album=".$this->music_id."\">list ".$this->numtracks." tracks</a>";

	}

	function is_album() {
		if ($this->music_type == "album" ) {
			return true;
		}
		return false;
	}
	
	function get_enqueue_link() {
		return "process-requests.php?req=enqueue&music_type=$this->music_type&music_id=$this->music_id&location=".get_location();
	}
	
	function lookup_info() {
		if ($this->is_album() ) {

			$q = "select album_name as title, album_genre as genre, albums.artist_name as artist, album_duration as duration, numtracks as numtracks, copyright, copyright_year, composer, conductor, album_upc from albums where albums.album_id='".$this->music_id."'";
		} else {
			$q =  "select track_name as title, track_work as work, composer, conductor,  album_id as aid, artist_name as artist, duration as duration from tracks where track_id = '".$this->music_id."'";
		}
		$q = db_query($q);
		if ($r = db_fetch_array($q)) {
			$this->artist = $r[artist];
			$this->title  = $r[title];
			$this->work = $r[work];
			$this->time = $r[duration];	
			$this->numtracks = $r[numtracks];
			$this->copyright = $r[copyright] . ", " . $r[copyright_year];
			$this->composer = $r[composer];
			$this->conductor = $r[conductor];
			$this->upc = $r[album_upc];
			$this->genre = $r[genre];
			if ($r[aid] != "") {
				$this->on_album = new Music("album", $r[aid]);
			
		}
		}

	}

	function get_songs() {
		if ($this->songs != "") {
			return $this->songs;
		}
		if ($this->is_album()) {
		

		$q = db_query("select track_id from tracks where album_id=$this->music_id order by track_number asc"); # KJW 10/18, changed from track_id
		$i = 0;
		while ($r = db_fetch_array($q)) {
				$this->songs[$i++] = new Music("song", $r[track_id]);
			}
		return $this->songs;
		}

		return 0;
	}
}
?>
