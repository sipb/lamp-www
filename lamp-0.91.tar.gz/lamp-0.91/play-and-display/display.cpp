#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>

extern "C" {
#include <ppm.h>
}

#include "display.h"

int color( int red, int green, int blue, float opacity )
{
  int newred = int(205 * (1 - opacity) + red * opacity);
  int newgreen = int(219 * (1 - opacity) + green * opacity);
  int newblue = int(240 * (1 - opacity) + blue * opacity);

  return ((newred << 8) & 63488) | ((newgreen << 3) & 2016) | (newblue >> 3);
}

LampDisplay::LampDisplay( int mywidth, int myheight )
{
  XSizeHints myhint;
  XEvent     myevent;

  /* open display */
  mydisplay = XOpenDisplay( "" );
  if ( mydisplay == NULL ) {
    perror( "XOpenDisplay" );
    exit( 1 );
  }
  myscreen = DefaultScreen( mydisplay );
  mydepth  = DefaultDepth( mydisplay, myscreen );
  myvisual = DefaultVisual( mydisplay, myscreen );

  printf( "Depth: %i\n", mydepth );

  /* white, black */
  mybg     = WhitePixel( mydisplay, myscreen );
  myfg     = BlackPixel( mydisplay, myscreen );

  /* size, location */
  myhint.width  = mywidth;
  myhint.height = myheight;
  myhint.x = 0;
  myhint.y = 0;
  // myhint.flags = PSize | PPosition;

  myhint.flags = PSize;

  /* create window, gc */
  mywindow = XCreateSimpleWindow( mydisplay, DefaultRootWindow( mydisplay ),
				  myhint.x, myhint.y,
				  myhint.width, myhint.height,
				  0, myfg, mybg );

  XSetStandardProperties( mydisplay, mywindow, "xphase", "xphase",
			  None, NULL, 0, &myhint );

  mygc = XCreateGC( mydisplay, mywindow, 0, 0 );
  XSetBackground( mydisplay, mygc, mybg );
  XSetForeground( mydisplay, mygc, myfg );

  /* select events */
  XSelectInput( mydisplay, mywindow, ExposureMask | ButtonPressMask );

  /* create image */
  myimage = XCreateImage( mydisplay, myvisual, mydepth, ZPixmap,
			  0, 0, mywidth, myheight - subheight, 32, 0 );

  myimage->data = (char *)malloc( myimage->bytes_per_line * (myheight - subheight) );
  /* will be freed by XDestroyImage() in ~LampDisplay() */
  if ( myimage->data == NULL ) {
    perror( "malloc" );
    exit( 1 );
  }
  
  /* get various parameters */
  image_data      = myimage->data;
  height          = myheight;
  width           = mywidth;
  bytes_per_line  = myimage->bytes_per_line;
  bits_per_pixel =  myimage->bits_per_pixel;

  /* clear image and put in window */
  for ( int x = 0; x < myimage->width; x++ ) {
    for ( int y = 0; y < myimage->height; y++ ) {
      XPutPixel( myimage, x, y, mybg );
    }
  }

  update();

  /* map window */
  XMapRaised( mydisplay, mywindow );

  /* get initial event */
  XNextEvent( mydisplay, &myevent );
}

LampDisplay::~LampDisplay( void )
{
  /* destroy objects */
  XDestroyImage( myimage );
  XFreeGC( mydisplay, mygc );
  XDestroyWindow( mydisplay, mywindow );
  XCloseDisplay( mydisplay );
}

void LampDisplay::update( void )
{
  XPutImage( mydisplay, mywindow, mygc, myimage,
	     0, 0, 0, 0, width, height );
}

void LampDisplay::getclick( int *x, int *y, int *button )
{
  XEvent               myevent;
  XExposeEvent        *myexpose;
  XButtonEvent        *mybutton;
  XButtonPressedEvent *mypressed;

  myexpose =  (XExposeEvent *)&myevent;
  mybutton =  (XButtonEvent *)&myevent;
  mypressed = (XButtonPressedEvent *)&myevent;

  while ( 1 ) {
    XNextEvent( mydisplay, &myevent );

    if ( myevent.type == Expose && myexpose->count == 0 ) {
      update();
    } else if ( myevent.type == ButtonPress) {
      *y = mybutton->x;
      *x = mybutton->y;
      *button = mybutton->button;
      return;
    }
  }
}

void LampDisplay::ppm_import( pixel** ppmarray, float opacity )
{
  for ( int line = 0; line < myimage->height; line++ ) {
    unsigned short *pixel16 = (unsigned short *)
      (image_data + line * bytes_per_line);
    unsigned long *pixel32 = (unsigned long *)
      (image_data + line * bytes_per_line);
    
    for ( int col = 0; col < width; col++ ) {
      pixel mypixel = ppmarray[line][col];
      unsigned char red = PPM_GETR( mypixel );
      unsigned char green = PPM_GETG( mypixel );
      unsigned char blue = PPM_GETB( mypixel );

      if ( bits_per_pixel == 16 ) {
	*(pixel16)++ = color( red, green, blue, opacity );
      } else {
	*(pixel32++) = (red << 16) | (red << 8) | red;
      }
    }
  }
}
