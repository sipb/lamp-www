#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <malloc.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/soundcard.h>
#include <string.h>
#include <sys/types.h>
#include <sys/un.h>
#include <sys/poll.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <mad.h>
#include <sched.h>
#include <sys/mman.h>

#define SAMPLE unsigned short
const int BUFFSIZE = 352800;
#define NUM_CHANNELS 13

struct pollfd ufds[ NUM_CHANNELS + 1 ];
int frag;
int card_bufsize;
int dispsocket;
int format, stereo;
char zeros[ BUFFSIZE ];
char packet[ 1024 ];

static inline
signed int scale(mad_fixed_t sample)
{
  /* round */
  sample += (1L << (MAD_F_FRACBITS - 16));

  /* clip */
  if (sample >= MAD_F_ONE)
    sample = MAD_F_ONE - 1;
  else if (sample < -MAD_F_ONE)
    sample = -MAD_F_ONE;

  /* quantize */
  return sample >> (MAD_F_FRACBITS + 1 - 16);
}

class Channel {
public:
  int index;
  int audio_fd;
  char *buffer;
  int length;
  int position;
  int desired_position;
  char timing_string[ 256 ];
  char save_timing_string[ 256 ];
  char playing;
  char need_audio;
  char end_of_stream;
  char length_found;
  char present;
  int decodeindex;
  int playindex;
  int file_fd;
  size_t file_length;
  const unsigned char *mp3data;
  char play_packet[ 1024 ];
  char filename[ 1024 ];
  char username[ 1024 ];
  char song_title[ 1024 ];
  unsigned int timeout;
  int percent;

  struct mad_stream Stream;
  struct mad_frame Frame;
  struct mad_synth Synth;
  mad_timer_t Timer;

  Channel( int i ) {
    index = i;
    char device_name[1024];
    int num = i < 8 ? i : i + 16;
    snprintf( device_name, 1024, "/dev/dsp%d", num );

    decodeindex = 0;
    playindex = 0;
    
    if ( ( audio_fd = open( device_name, O_WRONLY, 0 )) == -1 ) {
      perror( device_name );
      exit( 1 );
    }

    if ( ioctl( audio_fd, SNDCTL_DSP_SETFMT, &format ) != 0 ) {
      perror( "SNDCTL_DSP_SETFMT" );
      exit( 1 );
    }

    if ( ioctl( audio_fd, SNDCTL_DSP_STEREO, &stereo ) != 0 ) {
      perror( "SNDCTL_DSP_STEREO" );
      exit( 1 );
    }

    if ( fcntl( audio_fd, F_SETFL, O_NONBLOCK ) != 0 ) {
      perror( "fcntl" );
      exit( 1 );
    }

    ufds[ i ].fd = audio_fd;
    ufds[ i ].events = POLLOUT;

    /* set up buffer */
    buffer = (char *) malloc( BUFFSIZE );
    if ( buffer == NULL ) {
      perror( "malloc" );
      exit( 1 );
    }
    
    memset( buffer, 0, BUFFSIZE );

    playing = 0;
    present = 0;

    strcpy( save_timing_string, "" );    
  }

  void play( void ) {
    memcpy( play_packet, packet, 1024 );

    if ( (present == 0) || (playing == 0) || (end_of_stream == 0) ) {
      memset( buffer, 0, BUFFSIZE ); 
      decodeindex = 0;
      playindex = 0;
    }

    stop();

    char *stringp = play_packet + 12;
      
    char delim[2];
    delim[0] = -1;
    delim[1] = 0;
      
    strcpy( filename, strsep( &stringp, delim ) );
    strcpy( username, strsep( &stringp, delim ) );
    strcpy( song_title, strsep( &stringp, delim ) );

    file_fd = open( filename, O_RDONLY );
    if ( file_fd == -1 ) {
      fprintf( stderr, "Can't open %s\n", filename );
      perror( "open" );
      return;
    }

    struct stat my_stat;
    if ( stat( filename, &my_stat ) < 0 ) {
      fprintf( stderr, "stat(%s) gives error.\n", filename );
      perror( "stat" );
      exit( 1 );
    }

    file_length = my_stat.st_size;

    mp3data = (const unsigned char *) mmap( NULL, file_length, PROT_READ, MAP_SHARED, file_fd, 0 );
    if ( mp3data < 0 ) {
      perror( "mmap" );
      exit( 1 );
    }

    length_found = 0;

    mad_stream_init(&Stream);
    mad_timer_reset(&Timer);

    mad_stream_buffer( &Stream, mp3data, file_length );

    present = 1;
    need_audio = 1;
    end_of_stream = 0;
  }

  void length_tick ( void ) {
    if (length_found) {
      fprintf( stderr, "length_tick called but length already found.\n" );
      exit( 1 );
    }
    int tries = 0;
    while ( tries < 200 ) {
      struct mad_header Header;
      mad_header_decode(&Header, &Stream);
      mad_timer_add( &Timer, Header.duration );
      tries++;
      if ( Stream.error == MAD_ERROR_BUFLEN ) {
	break;
      }
    }
    if ( Stream.error == MAD_ERROR_BUFLEN ) {
      length_found = 1;
      length = Timer.seconds * 44100;

      int *packet_i = (int *)play_packet;

      char sendpacket[ 1024 ];

      timeout = packet_i[ 1 ];
      percent = packet_i[ 2 ];
      
      mad_stream_finish(&Stream);
      mad_stream_init(&Stream);
      mad_frame_init(&Frame);
      mad_synth_init(&Synth);
      mad_timer_reset(&Timer);

      mad_stream_buffer( &Stream, mp3data, file_length );
      
      desired_position = (length / 100) * percent;

      int play_margin = decodeindex - playindex;
      while ( play_margin < 0 ) {
	play_margin += BUFFSIZE;
      }

      position = desired_position - (play_margin/2);
    
      int chan = index + 63;

      memset( sendpacket, 0, 1024 );
      sendpacket[ 0 ] = 0;
      sendpacket[ 1 ] = chan;
      strcat( song_title, " " );
      memcpy( &(sendpacket[ 2 ]), &song_title, strlen( song_title ) );
      write( dispsocket, sendpacket, 1024 );
      
      memset( sendpacket, 0, 1024 );
      sendpacket[ 0 ] = 2;
      sendpacket[ 1 ] = chan;
      memcpy( &(sendpacket[ 2 ]), &username, strlen( username ) );
      write( dispsocket, sendpacket, 1024 );	
      
      memset( sendpacket, 0, 1024 );
      sendpacket[ 0 ] = 3;
      sendpacket[ 1 ] = chan;
      memcpy( &(sendpacket[ 2 ]), &timeout, sizeof( unsigned int ) );
      write( dispsocket, sendpacket, 1024 );

      char save_playing = playing;
      playing = 1;
      send_timing();
      playing = save_playing;
    }
  }

  void stop( void ) {
    if ( present ) {
      mad_synth_finish(&Synth);
      mad_frame_finish(&Frame);
      mad_stream_finish(&Stream);
      munmap( (void*)mp3data, file_length );
      close( file_fd );
      playing = 0;
      present = 0;
    }
  }

  void pause( void ) {
    if ( present ) {
      playing = 0;
    }
  }

  void resume( void ) {
    if ( present ) {
      playing = 1;
    }
  }

  void play_tick( void ) {
    audio_buf_info info;

    if ( ioctl( audio_fd, SNDCTL_DSP_GETOSPACE, &info ) < 0 ) {
      perror( "ioctl SNDCTL_DSP_GETOSPACE" );
    }

    for ( int i = 0; i < info.fragments; i++ ) {
      play_frag();
    }

    send_timing();
  }

  void tick( void ) {
    int decode_margin = playindex - decodeindex;
    while ( decode_margin < BUFFSIZE ) {
      decode_margin += BUFFSIZE;
    }
    if ( end_of_stream || ((decode_margin > 0) && (decode_margin < 9000)) ) {
      need_audio = 0;
      return;
    } else {
      need_audio = 1;
    }

    struct mad_header Header;

    int tries = 0;
    while ( (Timer.seconds * 44100 < desired_position) && (tries < 200) ) {
      mad_header_decode( &Header, &Stream );
      mad_timer_add( &Timer, Header.duration );
      tries++;
    }

    if ( Timer.seconds * 44100 < desired_position ) {
      return;
    }

    mad_frame_decode( &Frame, &Stream );
    mad_timer_add( &Timer, Frame.header.duration );

    mad_synth_frame( &Synth, &Frame );

    for ( int i = 0; i < Synth.pcm.length; i++ ) {
      int LeftSample, RightSample;

      LeftSample = scale(Synth.pcm.samples[0][i]);
      RightSample = scale(Synth.pcm.samples[1][i]);

      SAMPLE the_sample = int((LeftSample + RightSample) * 0.4);
      
      buffer[ decodeindex ] = the_sample & 0xff;
      buffer[ decodeindex + 1 ] = the_sample >> 8;
      decodeindex += 2;
      if ( decodeindex >= BUFFSIZE ) {
	decodeindex -= BUFFSIZE;
      }
    }

    if ( Stream.error == MAD_ERROR_BUFLEN ) {
      need_audio = 0;
      end_of_stream = 1;
      char tmp[ 1024 ];
      snprintf( tmp, 1024, "/usr/local/bin/lamp-endofsong %d &", index + 63 );
      system( tmp );
    }

    decode_margin = playindex - decodeindex;
    while ( decode_margin < BUFFSIZE ) {
      decode_margin += BUFFSIZE;
    }
    if ( (decode_margin > 0) && (decode_margin < 9000) ) {
      need_audio = 0;
      return;
    } else {
      need_audio = 1;
    }
  }

  void play_frag( void ) {
    if ( !playing ) {
      write( audio_fd, zeros, frag );
      return;
    }
    int play_margin = decodeindex - playindex;
    while ( play_margin < 0 ) {
      play_margin += BUFFSIZE;
    }
    if ( play_margin < frag - 1 ) {
      write( audio_fd, zeros, frag );
      return;
    }
    char scratch[ BUFFSIZE ];
    for ( int i = 0; i < frag; i++ ) {
      scratch[ i ] = buffer[(playindex + i) % BUFFSIZE];
    }
    playindex += frag;
    while ( playindex > BUFFSIZE ) {
      playindex -= BUFFSIZE;
    }
    write( audio_fd, scratch, frag );
    position += (frag / sizeof(SAMPLE));

    int decode_margin = playindex - decodeindex;
    while ( decode_margin < 0 ) {
      decode_margin += BUFFSIZE;
    }
    if ( (decode_margin > 0) && (decode_margin < 9000) ) {
      need_audio = 0;
      return;
    } else {
      need_audio = 1;
    }
  }

  void send_timing( void ) {
    if ( end_of_stream ) {
      return;
    }
    
    int my_position = position;
    if ( position < 0 ) my_position = 0;

    snprintf( timing_string, 256, "[%d:%.2d/%d:%.2d] ",
    	      (my_position / 44100) / 60,
    	      (my_position / 44100) % 60,
    	      (length / 44100) / 60,
    	      (length / 44100) % 60 );

    /*
    int play_margin = decodeindex - playindex;
    while ( play_margin < 0 ) {
      play_margin += BUFFSIZE;
    }

    int buffered_bytes;
    ioctl( audio_fd, SNDCTL_DSP_GETODELAY, &buffered_bytes );

    snprintf( timing_string, 256, "[%d/%d] ", play_margin, buffered_bytes );
    */

    if ( strcmp( timing_string, save_timing_string ) != 0 ) {
      strcpy( save_timing_string, timing_string );
      char spacket[ 1024 ];
      memset( spacket, 0, 1024 );
      spacket[ 0 ] = 1;
      spacket[ 1 ] = index + 63;
      memcpy( &(spacket[ 2 ]), &(save_timing_string),
	      strlen( save_timing_string ) );
      write( dispsocket, spacket, 1024 );
    }
  }
};

int main( void );
int max( int a, int b );

int max( int a, int b )
{
  return (a > b) ? a : b;
}

int main( void )
{
  Channel *channel[ NUM_CHANNELS ];
  int mysocket = socket( PF_UNIX, SOCK_DGRAM, 0 );
  dispsocket = socket( PF_UNIX, SOCK_DGRAM, 0 );
  struct sockaddr_un mysockaddr;

  format = AFMT_S16_LE;
  stereo = 0;

  for ( int i = 0; i < NUM_CHANNELS; i++ ) {
    channel[ i ] = new Channel( i );
  }

  /* get fragment size */
  if ( ioctl( channel[ 0 ]->audio_fd, SNDCTL_DSP_GETBLKSIZE, &frag ) != 0 ) {
    perror( "SNDCTL_DSP_GETBLKSIZE" );
    exit( 1 );
  }

  fprintf( stderr, "fragment size: %d\n", frag );

  /* set up sockets */
  mysockaddr.sun_family = AF_UNIX;
  strcpy( mysockaddr.sun_path, "/tmp/lamp-play-socket" );
  unlink( "/tmp/lamp-play-socket" );
  umask( 0 );
  if ( bind( mysocket, (struct sockaddr *) (&mysockaddr), sizeof( mysockaddr )  ) != 0 ) {
    perror( "bind" );
    exit( 1 );
  }
  strcpy( mysockaddr.sun_path, "/tmp/lamp-display-socket" );
  if ( connect( dispsocket, (struct sockaddr *) (&mysockaddr), sizeof( mysockaddr )  ) != 0 ) {
    perror( "connect" );
  }

  memset( zeros, 0, BUFFSIZE );

  ufds[ NUM_CHANNELS ].fd = mysocket;
  ufds[ NUM_CHANNELS ].events = POLLIN;

  while( 1 ) {
    poll( ufds, NUM_CHANNELS + 1, -1 );
    
    if ( ufds[ NUM_CHANNELS ].revents & POLLIN ) { // socket
      memset( packet, 0, 1024 );
      read( mysocket, packet, 1024 );

      if ( packet[ 0 ] == 0 ) { /* play song */
	int chan = packet[ 1 ];
	if ( (chan < 63) || (chan > 63 + NUM_CHANNELS) ) {
	  fprintf( stderr, "Bad chan %d\n", chan );
	  exit( 1 );
	}
	
	int index = chan - 63;
	channel[ index ]->play();
      } else if ( packet[ 0 ] == 1 ) { /* stop */
	int chan = packet[ 1 ];
	if ( (chan < 63) || (chan > 63 + NUM_CHANNELS) ) {
	  fprintf( stderr, "Bad chan %d\n", chan );
	  exit( 1 );
	}

	int index = chan - 63;
	channel[ index ]->stop();
      } else if ( packet[ 0 ] == 2 ) { /* pause */
	int chan = packet[ 1 ];
	if ( (chan < 63) || (chan > 63 + NUM_CHANNELS) ) {
	  fprintf( stderr, "Bad chan %d\n", chan );
	  exit( 1 );
	}

	int index = chan - 63;
	channel[ index ]->pause();
      } else if ( packet[ 0 ] == 3 ) { /* resume */
	int chan = packet[ 1 ];
	if ( (chan < 63) || (chan > 63 + NUM_CHANNELS) ) {
	  fprintf( stderr, "Bad chan %d\n", chan );
	  exit( 1 );
	}

	int index = chan - 63;
	channel[ index ]->resume();
      } else {
	exit( 1 );
      }
    }

    for ( int i = 0; i < NUM_CHANNELS; i++ ) {
      if ( channel[ i ]->present && (channel[ i ]->length_found == 0) ) {
	channel[ i ]->length_tick();
      }
    }

    for ( int i = 0; i < NUM_CHANNELS; i++ ) {
      if ( channel[ i ]->playing && channel[ i ]->need_audio && channel[ i ]->length_found ) {
	channel[ i ]->tick();
      }
    }

    for ( int i = 0; i < NUM_CHANNELS; i++ ) { // audio devices
      if ( ufds[ i ].revents & POLLOUT ) {
	channel[ i ]->play_tick();
      }
    }
  }
  
  return 0;
}
