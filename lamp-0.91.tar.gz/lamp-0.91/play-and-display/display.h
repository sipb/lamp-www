#ifndef DISPLAY_H
#define DISPLAY_H

#include <X11/Xlib.h>
#include <X11/Xutil.h>

extern "C" {
#include <ppm.h>
}

const int subheight = 320;

class LampDisplay {
 public:
  XImage    *myimage;
  Visual    *myvisual;
  Display   *mydisplay;
  Window     mywindow;
  GC         mygc;

  int           myscreen, mydepth;
  unsigned long myfg, mybg;

  char *image_data;
  int   height;
  int   width;
  int   bytes_per_line;
  int   bits_per_pixel;

  LampDisplay( int mywidth, int myheight ); 
  ~LampDisplay( void );
  
  void update( void );
  void getclick( int *x, int *y, int *button );
  void ppm_import( pixel** ppmarray, float opacity );
};

int color( int red, int green, int blue, float opacity );

#endif
